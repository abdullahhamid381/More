import React, { useState, lazy, Suspense, useEffect } from "react";
import { BrowserRouter as Router, Routes, Route } from "react-router-dom";
import Register from "./Pages/Register";
import { Provider, useSelector, useDispatch } from "react-redux";
import { store, signIN } from "./redux/userSlice";
import Login from "./Pages/Login";
import "./main.css";
import MyAccount from "./Pages/MyAccount";
import CreateAd from "./Pages/CreateAd";
import { ContextProvider } from "./Context/Context";
import ProductDetails from "./Pages/ProductDetails";
import { useNavigate, useParams } from "react-router-dom";
import Admin from "./Pages/Admin";
const Dashboard = lazy(() => import("./Pages/Dashboard"));

function Main() {
  const LoginBool = false;
  const [authenticated, setauthenticated] = useState(
    localStorage.getItem("@accessToken")
  );
  const [role, setRole] = useState(false);

  useEffect(() => {
    setauthenticated(localStorage.getItem("@accessToken"));
    let user =
      (localStorage.getItem("@role") == "true" ? true : false) || false;

    // setRole(user?.user?.admin);
    setRole(user);
  }, [LoginBool]);

  return authenticated !== "" && !role ? (
    <Router>
      <Routes>
        <Route path="/" element={<Dashboard />} />
        <Route path="/MyAccount" element={<MyAccount />} />
        <Route path="/CreateAd" element={<CreateAd />} />
        <Route path="/ProductDetails/:id" element={<ProductDetails />} />
      </Routes>
    </Router>
  ) : authenticated !== "" && role ? (
    <Router>
      <Routes>
        <Route path="/" element={<Admin />} />
      </Routes>
    </Router>
  ) : (
    authenticated == "" && (
      <>
        <Router>
          <Routes>
            <Route
              path="/"
              element={
                <Login authenticated={setauthenticated} role={setRole} />
              }
            />
            <Route path="/Register" element={<Register />} />

            <Route path="*" element={<>not found</>} />
          </Routes>
        </Router>
      </>
    )
  );
}

function App() {
  return (
    <ContextProvider>
      <Main />
    </ContextProvider>
  );
}

export default App;
