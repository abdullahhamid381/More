import React from "react";

function Idcardunfilled() {
  return (
    <svg
      width="27"
      height="23"
      viewBox="0 0 27 23"
      fill="none"
      xmlns="http://www.w3.org/2000/svg"
    >
      <path
        d="M24.9583 1H2.04167C1.46637 1 1 1.46637 1 2.04167V20.7917C1 21.367 1.46637 21.8333 2.04167 21.8333H24.9583C25.5336 21.8333 26 21.367 26 20.7917V2.04167C26 1.46637 25.5336 1 24.9583 1Z"
        stroke="#2F2F2F"
        stroke-opacity="0.74"
        stroke-width="2"
        stroke-linecap="round"
        stroke-linejoin="round"
      />
    </svg>
  );
}

export default Idcardunfilled;
