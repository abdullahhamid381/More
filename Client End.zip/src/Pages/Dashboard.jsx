import React, { useEffect, useState } from "react";
import Navbar from "../Components/Navbar";
import EditIcon from "@mui/icons-material/Edit";
import CallIcon from "@mui/icons-material/Call";
import Footer from "../Components/Footer/Footer";
import { GetAllAds, updateAd } from "../http/Services";
import CategoryDropdown from "../Components/CategoryDropDown";
import SearchBar from "../Components/SearchBar.js";
import Pagination from "@mui/material/Pagination";
import Stack from "@mui/material/Stack";
import { useNavigate } from "react-router-dom";
import axios from "../http/axiosSet.js";
const ProductComponent = ({ product }) => {
  const navigate = useNavigate();
  // const [selected, setSelected] = useState([]);
  // console.log("product", product._id);
  const handlePress = async () => {
    try {
      const resp = await updateAd(product._id, { view: 1 });
      if (resp.status === "OK") {
        console.log("view updated");
      }
    } catch (error) {
      console.log(error);
    }
  };

  return (
    <div
      className="flex flex-row w-[80%] min-w-[180px]  mr-5 relative  my-4 overflow-hidden  "
      onClick={() => navigate(`/ProductDetails/${product._id}`)}
    >
      <img
        src={`${axios.defaults.baseURL}/upload/image/${product.images[0]}`}
        className=" h-[180px]   rounded-t-lg "
        crossorigin="anonymous"
      />

      {/* <div className="bg-white w-full py-2  absolute top-[55.8%] rounded-t-3xl "></div> */}

      <div className="bg-cyan-500 w-full p-5  rounded-b-lg ">
        <div className="flex justify-center items-center flex-col">
          <p className="font-Poppins font-medium text-[1.25rem] text-[#2F2F2F]">
            {product.title}
          </p>
          <p className="font-Poppins font-medium text-[1.25rem] text-[#2F2F2F]">
            {product.description}
          </p>
          <p className="font-Poppins font-bold text-[2.25rem] text-[#2F2F2F]">
            {product.price}Rs
          </p>
          {/* make add buttun bg green */}
          <div
            className="flex flex-row justify-center items-center bg-[#35B368] text-[#FFF] rounded-[5px] font-Poppins font-medium text-[1.25rem] py-2 px-14 mobile:hidden cursor-pointer "
            onClick={() => handlePress()}
          >
            <CallIcon sx={{ color: "#FFF", width: 18, height: 18 }} />
            Contact
          </div>
          <p className="font-Poppins font-medium text-[1.25rem] text-[#2f2f2f] self-start">
            Category: {product.category[0]}
          </p>
        </div>
      </div>
    </div>
  );
};

function Dashboard() {
  console.log(`${axios.defaults.baseURL}/upload/image/`);
  //====================================================================
  const getProductsData = (state, filter) => {
    let products = state;
    if (filter.category && filter.category.length > 0) {
      console.log("filter", filter);
      products = products.filter((product) =>
        filter.category.some((cat) =>
          product.category.includes(cat.toLowerCase())
        )
      );
    }
    if (filter.search) {
      products = products.filter((product) =>
        product.title.toLowerCase().includes(filter.search)
      );
    }
    return products;
  };
  //====================================================================
  const [products, setProducts] = useState([]);
  //selected category
  const [selectedCategory, setSelectedCategory] = useState("");
  //list of categories
  const [categories, setCategories] = useState(["massage", "spa", "gym"]);
  //clenup useEffect try catch
  const [search, setsearch] = useState("");
  const [selectedCat, setSelectedCat] = useState("");
  const [page, setPage] = useState(1);
  useEffect(() => {
    const fetchAds = async () => {
      try {
        const resp = await GetAllAds(
          selectedCat !== "" && { category: { $in: selectedCat } },
          page //include selected categories
        );
        if (resp.status === "OK") {
          setProducts(resp.data);
        }

        // setProducts(resp);
      } catch (error) {
        console.log(error);
      }
    };
    fetchAds();
  }, [selectedCat, page]);

  // For storing Slected Categories in useState array which categories are selected
  const handleTagClicked = (category) => {
    let index = selectedCat.indexOf(category);
    let temp = [];
    if (index !== -1) {
      return;
    } else {
      temp = [category];
    }
    setSelectedCat(temp);
  };
  // ====================================================================
  const displayProducts = getProductsData(products, {
    category: selectedCat,
    search: search.length > 0 ? search : null,
  });

  return (
    <div className="min-h-screen min-w-full flex flex-col">
      {/* write me a  */}
      <Navbar />
      <div className="flex-1">
        <div className="flex  px-10">
          <SearchBar setName={setsearch} />
          <CategoryDropdown
            categories={categories}
            onSelect={handleTagClicked}
          />
        </div>
        <div className="flex flex-col border-[#2F2F2F17]  px-10 my-14 flex-wrap  ">
          {displayProducts.map((product) => (
            <ProductComponent product={product} />
          ))}
        </div>
        <div className="w-full items-center justify-center my-8 ">
          <Pagination
            count={10}
            color="primary"
            size="large"
            boundaryCount={10}
            sx={{ display: "flex", justifyContent: "center" }}
            onChange={(e, page) => setPage(page)}
          />
        </div>
      </div>

      <div className=" ">
        <Footer />
      </div>
    </div>
  );
}

export default Dashboard;
