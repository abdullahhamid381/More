import React, { useContext, useState } from "react";
import Navbar from "../Components/Navbar";
import TextField from "@mui/material/TextField";
import Context from "../Context/Context";
import InputLabel from "@mui/material/InputLabel";
import FormControl from "@mui/material/FormControl";
import Select from "@mui/material/Select";
import MenuItem from "@mui/material/MenuItem";
import { postAd, postImages } from "../http/Services";

function MyAccount() {
  const [categories, setCategories] = useState(["massage", "spa", "gym"]);
  const [Obj, setObj] = React.useState({
    title: "",
    description: "",
    price: "",
    category: [],
    images: [
      "https://tropicalspa.pk/wp-content/uploads/2023/01/Massage-Services-1536x1152.jpg",
    ],
    worker: { name: "", age: "", gender: "" },
    transaction: "sell",
    telephone: "",
    status: "accepted",
    Location: "Islamabad",
  });
  console.log("Object", Obj);
  ///////////////////////////////////////   dropdown   ///////////////////////////////////////////////
  const [Category, setCategory] = React.useState("");

  const handleChange = (event) => {
    setCategory(event.target.value);
    if (Obj.category.includes(event.target.value)) {
      setObj({
        ...Obj,
        category: Obj.category.filter((item) => item !== event.target.value),
      });
      return;
    }
    setObj({ ...Obj, category: [...Obj.category, event.target.value] });
  };
  //////////////////////////////////
  const adPost = async (e) => {
    try {
      e.preventDefault();
      let formData = new FormData();

      let images = [];
      for (let i = 0; i < Obj.images.length; i++) {
        formData.append("files", Obj.images[i]);
      }
      // formData.append("files", Obj.images);
      let response = await postImages(formData);
      if (response) {
        images = response.map((item) => item.filename);
      }
      setObj({ ...Obj, images: images });
      let res = await postAd(Obj);
      console.log(res);
    } catch (err) {
      console.log(err);
    }
  };
  //////////////////////////////////
  return (
    <div className="min-h-screen min-w-full  ">
      <Navbar />
      {/* form div in */}
      <form onSubmit={adPost} encType="multipart/form-data">
        <div className="flex flex-col justify-center items-center ">
          <div className="w-[80%] h-screen bg-[#F4F8FF] border-2 border-[#9fb8e4] px-16 ">
            <p className="text-heading font-Poppins font-bold text-[4.25rem] text-left pt-20">
              Create Ad
            </p>
            <div className="flex  justify-around ">
              <div className="flex flex-col  w-[60%] ">
                <p className="text-subheading text-[18px] mt-5 ">
                  Enter following details to create an ad
                </p>
                <TextField
                  id="standard-basic"
                  value={Obj.title}
                  label="Title"
                  variant="standard"
                  style={{ width: "100%" }}
                  onChange={(event) => {
                    setObj({ ...Obj, title: event.target.value });
                  }}
                />
                <TextField
                  id="standard-basic"
                  value={Obj.description}
                  label={Obj.description == "" ? "description" : null}
                  variant="standard"
                  style={{ width: "100%", marginTop: "1rem" }}
                  onChange={(event) => {
                    setObj({ ...Obj, description: event.target.value });
                  }}
                />
                <TextField
                  id="standard-basic"
                  value={Obj.price}
                  label={Obj.price == "" ? "price" : null}
                  variant="standard"
                  style={{ width: "100%", marginTop: "1rem" }}
                  onChange={(event) => {
                    setObj({ ...Obj, price: parseInt(event.target.value) });
                  }}
                />
                <TextField
                  id="standard-basic"
                  value={Obj.telephone}
                  label={Obj.telephone == "" ? "+923485517555" : null}
                  variant="standard"
                  style={{ width: "100%", marginTop: "1rem" }}
                  onChange={(event) => {
                    setObj({ ...Obj, telephone: event.target.value });
                  }}
                />
                {/* add input for file type */}

                <div className="flex ">
                  <FormControl variant="standard" sx={{ m: 1, minWidth: 120 }}>
                    <InputLabel id="demo-simple-select-standard-label">
                      Category
                    </InputLabel>
                    <Select
                      labelId="demo-simple-select-standard-label"
                      id="demo-simple-select-standard"
                      value={Category}
                      onChange={handleChange}
                      label="Category"
                    >
                      <MenuItem value="">
                        <em>None</em>
                      </MenuItem>
                      {categories.map((item) => {
                        return <MenuItem value={item}>{item}</MenuItem>;
                      })}
                    </Select>
                  </FormControl>

                  <div className="bg-[#d3cfcf] text-[#2f2f2f]  font-Poppins font-bold text-[1.2rem] ml-5 mobile:hidden  ">
                    Note : You can select multiple categories by clicking on
                    them also you can deselect them by clicking on them again
                  </div>
                </div>
                <input
                  type="file"
                  multiple
                  onChange={(e) => setObj({ ...Obj, images: e.target.files })}
                />
                <div className="flex flex-row">
                  {Obj.category.map((item) => {
                    return (
                      <div className="bg-[#d3cfcf] text-[#2f2f2f]  font-Poppins font-bold text-[1.2rem] rounded-[8px] px-4 py-2 mt-5 ml-5">
                        {item}
                      </div>
                    );
                  })}
                </div>
              </div>
              <div>
                <p className="text-subheading text-[18px] mt-5 ">
                  Worker Details
                </p>
                <TextField
                  id="standard-basic"
                  value={Obj?.worker?.name}
                  label="name"
                  variant="standard"
                  style={{ width: "100%" }}
                  onChange={(event) => {
                    setObj({
                      ...Obj,
                      worker: { ...Obj.worker, name: event.target.value },
                    });
                  }}
                />
                <TextField
                  id="standard-basic"
                  value={Obj?.worker?.age}
                  label="age"
                  variant="standard"
                  style={{ width: "100%" }}
                  onChange={(event) => {
                    setObj({
                      ...Obj,
                      worker: {
                        ...Obj.worker,
                        age:
                          Obj.worker.age !== null
                            ? parseInt(event.target.value)
                            : 0,
                      },
                    });
                  }}
                />
                <TextField
                  id="standard-basic"
                  value={Obj?.worker?.gender}
                  label="gender"
                  variant="standard"
                  style={{ width: "100%" }}
                  onChange={(event) => {
                    setObj({
                      ...Obj,
                      worker: { ...Obj.worker, gender: event.target.value },
                    });
                  }}
                />
              </div>
            </div>
            <div className="flex  justify-center">
              <button
                type="submit"
                className="bg-[#70cd59] text-[#ffffff] font-Poppins font-bold text-[1.2rem] rounded-[8px] px-4 py-2 mt-5"
              >
                Create Ad +
              </button>
            </div>
          </div>
        </div>
      </form>
      {/* form div out */}
    </div>
  );
}

export default MyAccount;
